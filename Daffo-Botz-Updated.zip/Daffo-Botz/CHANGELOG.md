# Daffo-Botz Changelog

## Updated build — 2026-10-06

- HideTag tersedia untuk semua anggota grup.
- Fix Add/Kick/Promote/Demote untuk Neonize 0.5.2 dengan `ParticipantChange` enum.
- Add: handling error 463 `account_reachout_restricted` dan fallback invite link.
- SetPP: validasi dan konversi gambar ke JPEG RGB 640x640 menggunakan Pillow.
- Moderation auto-kick memakai enum Neonize yang benar.
- Pairing helper `pair.py` ditambahkan.
- Dependency Pillow ditambahkan.
