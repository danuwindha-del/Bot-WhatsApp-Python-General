from daffobot.app import DaffoBot


if __name__ == "__main__":
    bot = DaffoBot()
    bot.run()
