# Daffo-Botz

Starter WhatsApp bot berbasis **Python + Neonize** dengan arsitektur modular/OOP.

> Penting: Neonize memakai protokol WhatsApp Multi-Device/Linked Device yang bukan API resmi Meta. Gunakan nomor uji/secondary account terlebih dahulu. Perubahan protokol WhatsApp dapat memengaruhi bot dan penggunaan otomatisasi berlebihan dapat berisiko pada akun. Jangan gunakan untuk spam.

## Fitur

- Hide Tag / ghost mention seluruh anggota grup
- Buka/tutup grup
- Add, kick, promote, demote
- Ubah nama, deskripsi, dan foto grup
- Welcome message + auto responder
- Anti-link dan anti-toxic dengan sistem strike SQLite
- Sticker maker dari gambar/video/GIF
- Downloader video/audio via yt-dlp
- Tebak Kata, Susun Kata, dan Trivia (Open Trivia DB)
- Menu WhatsApp yang rapi

## Struktur

```text
Daffo-Botz/
├── main.py
├── requirements.txt
├── .env.example
├── Dockerfile
├── data/
├── downloads/
└── daffobot/
    ├── app.py
    ├── config.py
    ├── context.py
    ├── permissions.py
    ├── router.py
    ├── storage.py
    ├── utils.py
    └── features/
        ├── autoresponder.py
        ├── downloader.py
        ├── games.py
        ├── group.py
        ├── menu.py
        ├── moderation.py
        ├── sticker.py
        └── welcome.py
```

## Instalasi

Disarankan Python **3.11**. Neonize memerlukan Python 3.10+.

### 1. Install FFmpeg

Ubuntu/Debian:

```bash
sudo apt update && sudo apt install -y ffmpeg
```

Windows (winget):

```powershell
winget install Gyan.FFmpeg
```

### 2. Buat virtual environment dan install dependency

```bash
python -m venv .venv
```

Linux/macOS:

```bash
source .venv/bin/activate
pip install -r requirements.txt
```

Windows:

```powershell
.venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Konfigurasi

```bash
cp .env.example .env
```

Edit `.env`, terutama `OWNER_NUMBERS`. Gunakan nomor internasional tanpa `+`, misalnya `62812...`.

### 4. Jalankan

```bash
python main.py
```

Pada pairing pertama, QR akan tampil di terminal. Buka WhatsApp -> **Linked devices** -> **Link a device**, lalu scan QR. Session tersimpan di `data/whatsapp-session.db`.

## Command

```text
.menu
.hidetag [pesan]
.open
.close
.add 62812xxxx
.kick @user
.promote @user
.demote @user
.setname Nama Grup
.setdesc Deskripsi grup
.setpp
.welcome on|off
.antilink on|off
.antitoxic on|off
.sticker
.dl https://...
.mp3 https://...
.tebakkata
.susunkata
.trivia
.jawab ...
```

Untuk `.kick`, `.promote`, dan `.demote`, Anda dapat **tag pengguna, reply pesannya, atau tulis nomor**. Untuk `.setpp` dan `.sticker`, kirim media dengan caption command atau reply media lalu jalankan command.

## Catatan Hide Tag

`ghost_mentions` menyisipkan metadata mention tanpa menuliskan semua nama anggota di body pesan. Tampilan/notifikasi akhir tetap bergantung pada versi klien WhatsApp. Jangan menggunakan fitur ini untuk spam atau mention massal berulang.

## Downloader

`yt-dlp` mendukung banyak situs, tetapi beberapa platform dapat meminta login/cookies dan dukungannya dapat berubah. Gunakan hanya untuk media yang Anda miliki atau memang berhak Anda unduh, serta patuhi ketentuan platform.

## Docker

```bash
docker build -t daffo-botz .
docker run --rm -it   --env-file .env   -v "$PWD/data:/app/data"   -v "$PWD/downloads:/app/downloads"   daffo-botz
```

## Pengembangan selanjutnya

Untuk produksi, pertimbangkan Redis untuk rate limiting/cache, PostgreSQL untuk multi-instance, structured logging, health endpoint, queue worker khusus download/media, serta test suite. Jangan menjalankan dua proses memakai session UUID/database WhatsApp yang sama.

## Update kompatibilitas terbaru

Paket ini sudah memuat perbaikan yang dibuat selama pengujian Termux/Ubuntu:

- `hidetag` dapat digunakan semua anggota grup.
- Group participant action memakai `neonize.utils.enum.ParticipantChange`, memperbaiki error `'str' object has no attribute 'value'` pada kick/add/promote/demote.
- `.add` menangani respons WhatsApp `463 account_reachout_restricted` dengan pesan yang lebih jelas dan mencoba memberi link invite grup.
- `.setpp` mengunduh dan memvalidasi media, memperbaiki orientasi EXIF, mengubah gambar ke JPEG RGB 640x640, lalu mengunggahnya sebagai foto grup.
- Anti-link/anti-toxic kick otomatis juga memakai `ParticipantChange.REMOVE`.
- `pair.py` disertakan untuk pairing kode nomor dan mendeteksi session yang sudah tertaut.

### Termux/Ubuntu yang direkomendasikan

Gunakan Ubuntu PRoot + Python 3.11. Pastikan paket sistem berikut tersedia:

```bash
apt update
apt install -y ffmpeg file libmagic1
```

Jika distro Anda memakai nama paket t64, gunakan `libmagic1t64` sebagai pengganti `libmagic1`.

Buat venv dan install dependency:

```bash
uv venv --python 3.11 .venv
source .venv/bin/activate
uv pip install --python .venv/bin/python -r requirements.txt
```

Jalankan:

```bash
python main.py
```

> Jangan bagikan `data/whatsapp-session.db`. File tersebut adalah session login WhatsApp Anda.
