class MenuFeature:
    def __init__(self, router, settings):
        self.settings = settings
        router.add("menu", self.menu, aliases=("help",))

    def menu(self, ctx, _args: str) -> None:
        p = self.settings.prefix
        menu = f"""
╭━━━〔 *{self.settings.bot_name.upper()}* 〕━━━╮
┃ 🤖 _Smart WhatsApp Utility Bot_
┃ Prefix: `{p}`
╰━━━━━━━━━━━━━━━━━━━━╯

*👥 GROUP MANAGEMENT*
• `{p}hidetag [pesan]` — panggil semua member tanpa daftar nama (semua anggota)
• `{p}open` / `{p}close` — buka/tutup chat grup
• `{p}add 628xxx` — tambah anggota
• `{p}kick @user` — keluarkan anggota
• `{p}promote @user` / `{p}demote @user`
• `{p}setname Nama Baru`
• `{p}setdesc Deskripsi baru`
• `{p}setpp` — kirim/reply gambar lalu jalankan perintah
• `{p}welcome on|off`

*🛡️ MODERATION*
• `{p}antilink on|off`
• `{p}antitoxic on|off`

*🎨 MEDIA & UTILITY*
• `{p}sticker` — kirim/reply gambar, video pendek, atau GIF
• `{p}dl <url>` — unduh video yang didukung yt-dlp
• `{p}mp3 <url>` — ekstrak audio

*🎮 FUN & EDUKASI*
• `{p}tebakkata`
• `{p}susunkata`
• `{p}trivia`
• `{p}jawab <jawaban>`

_Use responsibly • Daffo-Botz_
""".strip()
        ctx.reply(menu)
