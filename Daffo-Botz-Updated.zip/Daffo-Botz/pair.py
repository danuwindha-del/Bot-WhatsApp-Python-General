"""Helper pairing Daffo-Botz.

Jika session sudah terautentikasi, script akan memberi tahu bahwa pairing tidak
perlu diulang. Jika belum, script akan mencoba menghasilkan kode pairing nomor.
"""
from __future__ import annotations

import re
import time
from threading import Event, Thread

from neonize.client import NewClient
from neonize.events import ConnectedEv, PairStatusEv

SESSION_DB = "data/whatsapp-session.db"

connected = Event()
qr_ready = Event()
paired = Event()
client = NewClient(SESSION_DB)


@client.event(ConnectedEv)
def on_connected(client, event):
    print("\n✅ WhatsApp sudah terautentikasi dan CONNECTED.")
    connected.set()


@client.event(PairStatusEv)
def on_pair_status(client, event):
    print("\n✅ Pairing WhatsApp berhasil.")
    paired.set()


def on_qr(client, qr_data):
    # QR tidak dicetak besar; event hanya dipakai sebagai tanda server pairing siap.
    qr_ready.set()


client.qr(on_qr)


def run_client():
    try:
        client.connect()
    except Exception as exc:
        print(f"\n❌ Koneksi gagal: {exc}")


thread = Thread(target=run_client, daemon=True)
thread.start()

print("Menghubungkan ke WhatsApp...")
time.sleep(5)

if connected.is_set():
    print("\n====================================")
    print("       DAFFO-BOTZ SUDAH TERTAUT")
    print("====================================")
    print("Tidak perlu melakukan pairing lagi.")
    print("Jalankan: python main.py")
    raise SystemExit(0)

if not qr_ready.wait(timeout=30):
    print("❌ Server pairing belum siap dalam 30 detik.")
    raise SystemExit(1)

phone = input("\nMasukkan nomor WhatsApp (contoh 6281234567890): ").strip()
phone = re.sub(r"\D", "", phone)
if phone.startswith("0"):
    phone = "62" + phone[1:]
if not phone.startswith("62"):
    print("❌ Gunakan format Indonesia 628xxxxxxxxxx")
    raise SystemExit(1)

try:
    code = client.PairPhone(phone, show_push_notification=True)
except Exception as exc:
    print(f"❌ Gagal mendapatkan kode pairing: {exc}")
    raise SystemExit(1)

print("\n====================================")
print("       KODE PAIRING DAFFO-BOTZ")
print("====================================")
print(f"\n          {code}\n")
print("====================================")
print("WhatsApp → Perangkat tertaut → Tautkan perangkat → Tautkan dengan nomor telepon")
print("Menunggu pairing...")

try:
    while True:
        if paired.is_set() or connected.is_set():
            print("\n🎉 Pairing berhasil. Sekarang jalankan: python main.py")
            break
        if not thread.is_alive():
            break
        time.sleep(1)
except KeyboardInterrupt:
    print("\nDihentikan.")
