# 3.1

- Antrean fair dua lane, pacing tanpa menahan lock saat sleep, metrik pemrosesan.
- Hilangkan round-trip AI tambahan pada setiap balasan command.
- AI tools dengan hasil nyata, konteks command, alias AI ke model terkonfigurasi, fallback provider tanpa tool support.
- Kalkulator AST terbatas, pencarian Wikipedia async + cache + sumber.
- Perbaiki bentrok sesi game, tebak bendera, KBBI, setdesc/revoke, audio message extraction.
- Terapkan switch entertainment/legacy, download limit dan strike limit.
- Dashboard playground, diagnostik, impor/ekspor, pengaturan pacing/AI, katalog status, edit grup, polling fallback.
- Sertakan legacy dalam build Docker, batasi executor, lindungi perintah owner dengan identitas PN.
- Pengujian regresi dan interaksi DOM/API, panduan upgrade mempertahankan sesi.
