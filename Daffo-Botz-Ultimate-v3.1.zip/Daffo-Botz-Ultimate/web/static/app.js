'use strict';
const $=id=>document.getElementById(id);
let csrf='',stream=null,pairTimer=null,lastConfig={},commandList=[],commandCatalog=[],pollTimer=null;

const featureFlags={anti_link:'Anti-link',anti_toxic:'Anti-toxic',entertainment:'Entertainment',downloader:'Media downloader',welcome:'Welcome message',interactive:'Interactive menu',legacy_features:'Daffo feature pack'};
const aiFlags={ai:'Daffo AI enabled',ai_private:'Auto reply • private chat',ai_group:'Auto reply • group chat',ai_command_assist:'Ingat hasil command',ai_tools:'AI tools & perintah bahasa alami'};

function notice(message){const n=$('notice');n.textContent=message;n.style.display='block';clearTimeout(notice.t);notice.t=setTimeout(()=>n.style.display='none',5000);}
async function api(path,method='GET',body){const r=await fetch('/api/'+path,{method,headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:body===undefined?undefined:JSON.stringify(body)});let d={};try{d=await r.json();}catch{}if(!r.ok){if(r.status===401)showLogin();throw Error(typeof d.detail==='string'?d.detail:'Permintaan tidak valid');}return d;}
function showLogin(){if(stream)stream.close();clearInterval(pairTimer);clearInterval(pollTimer);$('dashboard').hidden=true;$('login').hidden=false;$('logout').hidden=true;csrf='';}
function duration(s){s=Number(s||0);const d=Math.floor(s/86400),h=Math.floor((s%86400)/3600),m=Math.floor((s%3600)/60);return (d?d+'d ':'')+(h?h+'h ':'')+m+'m';}

async function pairing(){try{const d=await api('pairing');$('pairStatus').textContent=d.status==='connected'?'✅ Sesi tersimpan • WhatsApp terhubung':d.status==='demo'?'Mode demo':'Status: '+d.status;$('qr').hidden=!d.qr;if(d.qr)$('qr').src=d.qr;else $('qr').removeAttribute('src');}catch(e){notice(e.message);}}

function snapshot(d){
  $('status').textContent=d.status;
  $('mode').textContent=d.mode==='demo'?'DEMO':'Neonize / WhatsApp';
  $('incoming').textContent=d.incoming;$('outgoing').textContent=d.outgoing||0;
  $('commandCount').textContent=d.commands||0;$('groupCount').textContent=d.groups.length;
  $('aiSessions').textContent=d.ai?.sessions||0;$('uptime').textContent=duration(d.uptime);
  $('systemInfo').textContent=(d.system?.python||'')+' • '+(d.system?.platform||'');
  $('queue').textContent=d.queue;$('dropped').textContent=d.dropped;
  $('logs').textContent=d.logs.join('\n');
  renderGroups(d.groups);
  const info=$('runtimeInfo');info.innerHTML='';
  const pairs=[['Status',d.status],['Mode',d.mode],['Python',d.system?.python||'-'],['Platform',d.system?.platform||'-'],['Disk free',(d.system?.disk_free_mb||0)+' MB'],['Processed',d.processed||0],['Errors',d.errors||0],['Active jobs',d.active_jobs||0],['Mean duration',(d.latency_ms||0)+' ms'],['P95 duration',(d.p95_ms||0)+' ms'],['AI latency',(d.ai?.last_latency_ms||0)+' ms'],['Tool calls',d.ai?.tool_calls||0],['AI requests',d.ai?.requests||0],['AI circuit',d.ai?.circuit_open?'OPEN':'OK']];
  for(const [k,v] of pairs){const dt=document.createElement('dt');dt.textContent=k;const dd=document.createElement('dd');dd.textContent=v;info.append(dt,dd);}
  const c=$('chart'),ctx=c.getContext('2d');ctx.clearRect(0,0,900,190);const max=Math.max(1,...d.chart);ctx.strokeStyle='#33445f';ctx.beginPath();ctx.moveTo(0,160);ctx.lineTo(900,160);ctx.stroke();ctx.fillStyle='#6cf5bb';d.chart.forEach((n,i)=>ctx.fillRect(i*29+6,160-(n/max)*135,17,(n/max)*135));ctx.fillStyle='#8fa3bd';ctx.font='12px system-ui';ctx.fillText('−30 menit',0,185);ctx.fillText('Sekarang',835,185);ctx.fillText('Peak '+max+'/min',8,16);
}

function renderGroups(groups){
  const box=$('groups'),select=$('groupSelect');box.replaceChildren();const current=select.value;select.replaceChildren();
  for(const g of groups){const item=document.createElement('div');item.className='group';const title=document.createElement('b');title.textContent=g.name;const sub=document.createElement('small');sub.textContent=g.members+' anggota • '+g.jid;item.append(title,sub);box.append(item);const op=document.createElement('option');op.value=g.jid;op.textContent=g.name+' ('+g.members+')';select.append(op);}if([...select.options].some(x=>x.value===current))select.value=current;
}

function makeToggles(container,flags,c){container.replaceChildren();for(const [key,title] of Object.entries(flags)){const label=document.createElement('label');label.className='toggle';const txt=document.createElement('span');txt.textContent=title;const box=document.createElement('input');box.type='checkbox';box.checked=!!c[key];box.onchange=async()=>{box.disabled=true;try{await api('config','PATCH',{[key]:box.checked});await loadCommands();notice(title+' diperbarui');}catch(e){box.checked=!box.checked;notice(e.message);}finally{box.disabled=false;}};label.append(txt,box);container.append(label);}}

async function loadConfig(){const c=await api('config');lastConfig=c;for(const id of ['ai_base_url','ai_model','ai_temperature','ai_max_tokens','ai_memory_turns','ai_system_prompt','ai_timeout','ai_group_mode','send_interval','chat_send_interval','cooldown','max_download_mb','strike_limit','welcome_message'])if($(id))$(id).value=c[id];for(const id of ['admins','toxic_words'])$(id).value=(c[id]||[]).join(', ');$('keyStatus').textContent=c.ai_key_configured?'🔐 API key tersimpan & terenkripsi':'⚠️ API key belum diisi — AI auto reply belum dapat bekerja';$('ai_key').value='';makeToggles($('featureToggles'),featureFlags,c);makeToggles($('aiToggles'),aiFlags,c);}

async function loadCommands(){const d=await api('commands');commandList=d.commands;commandCatalog=d.catalog||[];renderCommands();}
function renderCommands(){const q=($('commandSearch').value||'').toLowerCase();$('commands').replaceChildren();for(const cmd of commandList.filter(x=>x.includes(q))){const b=document.createElement('button');b.className='commandChip';const meta=commandCatalog.find(x=>x.name===cmd);b.textContent='.'+cmd+(meta?.status==='provider'?' · Provider':'')+(meta?.enabled===false?' · OFF':'');b.title=meta?.category||'core';b.onclick=()=>{navigator.clipboard?.writeText('.'+cmd).then(()=>notice('Command .'+cmd+' disalin')).catch(()=>notice('Salin manual: .'+cmd));if(!navigator.clipboard)notice('Salin manual: .'+cmd);};$('commands').append(b);}}

async function enter(){await Promise.all([loadConfig(),loadCommands()]);snapshot(await api('status'));$('login').hidden=true;$('dashboard').hidden=false;$('logout').hidden=false;if(stream)stream.close();stream=new EventSource('/api/events');stream.onmessage=e=>{snapshot(JSON.parse(e.data));$('monitorState').textContent='Monitor live';};stream.onerror=()=>{$('monitorState').textContent='Monitor polling';};clearInterval(pollTimer);pollTimer=setInterval(async()=>{if(stream?.readyState!==EventSource.OPEN){try{snapshot(await api('status'));}catch{}}},5000);await pairing();clearInterval(pairTimer);pairTimer=setInterval(pairing,5000);}

for(const b of document.querySelectorAll('.tab'))b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tabPage').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelector(`[data-page="${b.dataset.tab}"]`).classList.add('active');};

$('loginForm').onsubmit=async e=>{e.preventDefault();try{const d=await api('login','POST',{username:$('username').value,password:$('password').value});csrf=d.csrf;$('password').value='';await enter();}catch(e){notice(e.message);}};
$('aiForm').onsubmit=async e=>{e.preventDefault();const data={};for(const id of ['ai_base_url','ai_model','ai_system_prompt'])data[id]=$(id).value;data.ai_temperature=Number($('ai_temperature').value);data.ai_max_tokens=Number($('ai_max_tokens').value);data.ai_memory_turns=Number($('ai_memory_turns').value);data.ai_timeout=Number($('ai_timeout').value);data.ai_group_mode=$('ai_group_mode').value;if($('ai_key').value)data.ai_key=$('ai_key').value;try{await api('config','PATCH',data);await loadConfig();notice('Daffo AI diperbarui');}catch(e){notice(e.message);}};
$('configForm').onsubmit=async e=>{e.preventDefault();const data={send_interval:Number($('send_interval').value),chat_send_interval:Number($('chat_send_interval').value),cooldown:Number($('cooldown').value),max_download_mb:Number($('max_download_mb').value),strike_limit:Number($('strike_limit').value),welcome_message:$('welcome_message').value};for(const id of ['admins','toxic_words'])data[id]=$(id).value.split(',').map(x=>x.trim()).filter(Boolean);try{await api('config','PATCH',data);await loadConfig();notice('Pengaturan bot tersimpan');}catch(e){notice(e.message);}};
$('clearKey').onclick=async()=>{if(!confirm('Hapus API key Daffo AI?'))return;try{await api('config','PATCH',{ai_key:'',ai:false});await loadConfig();notice('API key dihapus');}catch(e){notice(e.message);}};
$('clearMemory').onclick=async()=>{try{await api('ai/clear','POST',{});notice('Memori Daffo AI dibersihkan');}catch(e){notice(e.message);}};
for(const action of ['start','stop','restart'])$(action).onclick=async()=>{const b=$(action);for(const id of ['start','stop','restart'])$(id).disabled=true;try{await api('bot','POST',{action});snapshot(await api('status'));await pairing();notice('Bot: '+action);}catch(e){notice(e.message);}finally{for(const id of ['start','stop','restart'])$(id).disabled=false;}};
$('sendMessage').onclick=async()=>{try{await api('message','POST',{target:$('sendTarget').value,text:$('sendText').value});$('sendText').value='';notice('Pesan terkirim');}catch(e){notice(e.message);}};
$('refreshGroups').onclick=async()=>{try{const d=await api('groups/refresh','POST',{});renderGroups(d.groups);notice('Daftar group diperbarui');}catch(e){notice(e.message);}};
for(const b of document.querySelectorAll('.groupAction'))b.onclick=async()=>{try{const d=await api('group-action','POST',{jid:$('groupSelect').value,action:b.dataset.action,text:''});$('groupResult').textContent=d.result||'OK';}catch(e){notice(e.message);}};
$('groupSend').onclick=async()=>{try{const d=await api('group-action','POST',{jid:$('groupSelect').value,action:'message',text:$('groupText').value});$('groupResult').textContent=d.result;$('groupText').value='';}catch(e){notice(e.message);}};
$('commandSearch').oninput=renderCommands;
$('logout').onclick=async()=>{try{await api('logout','POST',{});showLogin();}catch(e){notice(e.message);}};

(async()=>{try{csrf=(await api('session')).csrf;await enter();}catch{showLogin();}})();

$('testAI').onclick=async()=>{const b=$('testAI');b.disabled=true;$('testResult').textContent='AI sedang memproses…';try{const d=await api('ai/test','POST',{prompt:$('testPrompt').value});$('testResult').textContent=d.answer+'\n\nDurasi: '+d.latency_ms+' ms';}catch(e){$('testResult').textContent=e.message;}finally{b.disabled=false;}};
$('diagnose').onclick=async()=>{try{const d=await api('diagnostics');$('diagnostics').replaceChildren();for(const c of d.checks){const p=document.createElement('p');p.textContent=(c.ok?'✅ ':'⚠️ ')+c.name+' — '+c.detail;$('diagnostics').append(p);}}catch(e){notice(e.message);}};
$('exportConfig').onclick=async()=>{try{const d=await api('config/export');const url=URL.createObjectURL(new Blob([JSON.stringify(d,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='daffo-settings.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){notice(e.message);}};
$('importConfig').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>30000)throw Error('Berkas maksimal 30 KB');const d=JSON.parse(await f.text());if(!d||typeof d!=='object'||Array.isArray(d))throw Error('Format harus objek JSON');delete d.ai_key_configured;if(!confirm('Terapkan '+Object.keys(d).length+' pengaturan dari berkas ini?'))return;await api('config','PATCH',d);await loadConfig();await loadCommands();notice('Pengaturan diimpor');}catch(e){notice(e.message);}finally{e.target.value='';}};
for(const [id,action] of [['groupName','name'],['groupDescription','description']])$(id).onclick=async()=>{try{const d=await api('group-action','POST',{jid:$('groupSelect').value,action,text:$('groupEditText').value});$('groupResult').textContent=d.result;await api('groups/refresh','POST',{});}catch(e){notice(e.message);}};
